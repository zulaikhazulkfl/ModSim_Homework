import tkinter


root = tkinter.Tk()

myCanvas = tkinter.Canvas(root, bg="yellow", height=500, width=600)

coord = 70, 90, 250, 250
arc = myCanvas.create_arc(coord, start=0, extent=300, fill="green")
arv2 = myCanvas.create_arc(coord, start=150, extent=215, fill="red")

myCanvas.pack()
root.mainloop()

